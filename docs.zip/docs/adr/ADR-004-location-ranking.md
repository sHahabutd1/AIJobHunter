# ADR-004: Location Ranking and Eligibility

- **Status:** Accepted
- **Date:** 2026-01-19

## Context

The candidate is based in Colorado and is willing to relocate anywhere in the United States. Remote work is also acceptable, but remote opportunities must be eligible for Colorado or otherwise satisfy the candidate's U.S. work-location requirements. The approved priority is Colorado first, relocation anywhere in the United States second, and remote anywhere in the United States third. Remote opportunities outside Colorado must not outrank acceptable relocation opportunities solely because they are remote.

## Decision

Evaluate location eligibility separately from preference ranking. A remote label by itself is insufficient: the posting must establish Colorado eligibility or otherwise meet the candidate's U.S. work-location requirements. If the work location or eligible states are unknown or ambiguous, mark the opportunity for review rather than assuming it is eligible.

Among opportunities that satisfy hard eligibility requirements, apply this location preference order:

1. Colorado opportunities.
2. Opportunities elsewhere in the United States that require relocation, since relocation is acceptable.
3. Remote opportunities elsewhere in the United States.

Represent the location rationale in the match explanation. Do not allow an LLM to override location eligibility or the approved priority. The exact numerical score weights, if any, are not fixed by this ADR and require validation before being adopted.

## Consequences

### Positive

- Location preference reflects the candidate's stated priorities rather than treating all remote roles as best matches.
- Work-location eligibility is explicit and reviewable.
- Unknown location details do not silently become positive matches.
- Relocation opportunities are correctly ranked above remote opportunities outside Colorado.

### Trade-offs

- Job descriptions may not clearly state eligible work locations, creating `NeedsReview` cases.
- Source data and employer policy can be incomplete or stale, so location eligibility may require user confirmation.
- A strict priority order may not capture every future preference nuance; the order can be revisited through a new ADR if requirements change.

## Alternatives Considered

- **Rank all remote roles above on-site roles:** Rejected because the candidate accepts relocation and explicitly prioritizes it above remote opportunities outside Colorado.
- **Treat every U.S. remote posting as eligible:** Rejected because employers may restrict remote work by state or location.
- **Let AI infer location eligibility:** Rejected because eligibility is a deterministic constraint and uncertain cases require review.
